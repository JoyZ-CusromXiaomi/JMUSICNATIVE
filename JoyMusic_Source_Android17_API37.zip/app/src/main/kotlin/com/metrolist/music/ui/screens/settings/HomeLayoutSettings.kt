package com.metrolist.music.ui.screens.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.metrolist.music.constants.HomeSectionOrderKey
import com.metrolist.music.constants.HomeSectionVisibilityKey
import com.metrolist.music.ui.component.Material3SettingsGroup
import com.metrolist.music.ui.component.Material3SettingsItem
import com.metrolist.music.utils.rememberPreference
import com.metrolist.music.R

private data class HomeBlockOption(val id: String, val title: String, val description: String)

private val homeBlockOptions = listOf(
    HomeBlockOption("speed_dial", "Speed Dial", "Akses cepat ke koleksi dan fitur favorit"),
    HomeBlockOption("quick_picks", "Quick Picks", "Rekomendasi lagu pilihan"),
    HomeBlockOption("daily_discover", "Daily Discover", "Temukan musik baru setiap hari"),
    HomeBlockOption("keep_listening", "Keep Listening", "Lanjutkan lagu yang pernah diputar"),
    HomeBlockOption("account_playlists", "Playlist akun", "Playlist dari akun YouTube Music"),
    HomeBlockOption("forgotten_favorites", "Forgotten Favorites", "Lagu favorit yang lama tidak diputar"),
    HomeBlockOption("from_the_community", "From the Community", "Playlist dari komunitas"),
    HomeBlockOption("mood_and_genres", "Mood & Genres", "Jelajahi musik berdasarkan suasana"),
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeLayoutSettings(navController: NavController) {
    val (hiddenRaw, setHiddenRaw) = rememberPreference(HomeSectionVisibilityKey, "")
    val hidden = hiddenRaw.split(",").filter { it.isNotBlank() }.toSet()
    val (orderRaw, setOrderRaw) = rememberPreference(HomeSectionOrderKey, "")
    val order = (orderRaw.split(",").filter { it.isNotBlank() } + homeBlockOptions.map { it.id })
        .distinct().filter { id -> homeBlockOptions.any { it.id == id } }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)
    ) {
        TopAppBar(
            title = { Text("Home customization") },
            navigationIcon = {
                IconButton(onClick = { navController.navigateUp() }) {
                    Icon(painterResource(R.drawable.arrow_back), contentDescription = "Back")
                }
            }
        )
        Text(
            "Atur bagian yang ingin ditampilkan di Home. Gunakan panah untuk mengubah urutannya.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(vertical = 12.dp)
        )
        homeBlockOptions.sortedBy { order.indexOf(it.id) }.forEachIndexed { index, option ->
            val visible = option.id !in hidden
            Material3SettingsGroup(
                items = listOf(
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.home_filled),
                        title = { Text(option.title) },
                        description = { Text(option.description) },
                        trailingContent = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(
                                    enabled = index > 0,
                                    onClick = {
                                        val mutable = order.toMutableList()
                                        val current = mutable.indexOf(option.id)
                                        if (current > 0) {
                                            val previous = mutable[current - 1]
                                            mutable[current - 1] = option.id
                                            mutable[current] = previous
                                            setOrderRaw(mutable.joinToString(","))
                                        }
                                    }
                                ) { Text("↑") }
                                IconButton(
                                    enabled = index < homeBlockOptions.size - 1,
                                    onClick = {
                                        val mutable = order.toMutableList()
                                        val current = mutable.indexOf(option.id)
                                        if (current < mutable.lastIndex) {
                                            val next = mutable[current + 1]
                                            mutable[current + 1] = option.id
                                            mutable[current] = next
                                            setOrderRaw(mutable.joinToString(","))
                                        }
                                    }
                                ) { Text("↓") }
                                Switch(
                                    checked = visible,
                                    onCheckedChange = { show ->
                                        val updated = if (show) hidden - option.id else hidden + option.id
                                        setHiddenRaw(updated.joinToString(","))
                                    }
                                )
                            }
                        }
                    )
                )
            )
            Spacer(Modifier.padding(bottom = 8.dp))
        }
    }
}
