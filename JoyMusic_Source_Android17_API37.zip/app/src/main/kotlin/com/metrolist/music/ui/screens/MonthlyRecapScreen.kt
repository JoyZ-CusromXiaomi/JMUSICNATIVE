package com.metrolist.music.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.metrolist.music.LocalDatabase
import com.metrolist.music.R
import com.metrolist.music.db.entities.Artist
import com.metrolist.music.db.entities.SongWithStats
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.Locale

private data class MonthlyRecapData(
    val songs: List<SongWithStats> = emptyList(),
    val artists: List<Artist> = emptyList(),
    val totalMs: Long = 0L,
    val uniqueSongs: Int = 0,
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MonthlyRecapScreen(navController: NavController) {
    val database = LocalDatabase.current
    val months = remember { (0L..11L).map { YearMonth.now().minusMonths(it) } }
    var selectedMonth by remember { mutableStateOf(months.first()) }
    var recap by remember { mutableStateOf(MonthlyRecapData()) }
    var loading by remember { mutableStateOf(true) }

    LaunchedEffect(selectedMonth) {
        loading = true
        recap = withContext(Dispatchers.IO) {
            val from = selectedMonth.atDay(1).atStartOfDay()
            val to = selectedMonth.atEndOfMonth().atTime(23, 59, 59, 999_999_999)
            MonthlyRecapData(
                songs = database.mostPlayedSongsStats(from, limit = 5, toTimeStamp = to).first(),
                artists = database.mostPlayedArtists(from, limit = 5, toTimeStamp = to).first(),
                totalMs = database.getTotalPlayTimeInRange(from, to).first() ?: 0L,
                uniqueSongs = database.getUniqueSongCountInRange(from, to).first(),
            )
        }
        loading = false
    }

    val monthLabel = selectedMonth.format(DateTimeFormatter.ofPattern("MMMM yyyy", Locale.getDefault()))
    val hours = recap.totalMs / 3_600_000L
    val minutes = (recap.totalMs / 60_000L) % 60L

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Monthly Recap") },
                navigationIcon = {
                    IconButton(onClick = { navController.navigateUp() }) {
                        Icon(painterResource(R.drawable.arrow_back), contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Text(monthLabel, style = MaterialTheme.typography.headlineMedium)
                Text(
                    "Your month in music",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(months) { month ->
                        FilterChip(
                            selected = selectedMonth == month,
                            onClick = { selectedMonth = month },
                            label = {
                                Text(month.format(DateTimeFormatter.ofPattern("MMM", Locale.getDefault())))
                            }
                        )
                    }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    RecapMetricCard("Listening time", if (hours > 0) "${hours}h ${minutes}m" else "${minutes}m", Modifier.weight(1f))
                    RecapMetricCard("Songs played", recap.uniqueSongs.toString(), Modifier.weight(1f))
                }
            }
            item {
                RecapSectionCard(
                    title = "Your top song",
                    primary = recap.songs.firstOrNull()?.title ?: if (loading) "Loading…" else "No listening data yet",
                    secondary = recap.songs.firstOrNull()?.artistName.orEmpty()
                )
            }
            item {
                RecapSectionCard(
                    title = "Your top artist",
                    primary = recap.artists.firstOrNull()?.artist?.name ?: if (loading) "Loading…" else "No listening data yet",
                    secondary = if (recap.artists.isNotEmpty()) "Most listened artist this month" else "Play some music and your recap will appear here"
                )
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh)) {
                    Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Top artists", style = MaterialTheme.typography.titleLarge)
                        if (recap.artists.isEmpty()) {
                            Text(if (loading) "Loading…" else "No artist data for this month yet.")
                        } else {
                            recap.artists.take(5).forEachIndexed { index, artist ->
                                Text("${index + 1}. ${artist.artist.name}", style = MaterialTheme.typography.titleMedium)
                            }
                        }
                    }
                }
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh)) {
                    Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Top 5 songs", style = MaterialTheme.typography.titleLarge)
                        if (recap.songs.isEmpty()) {
                            Text(if (loading) "Collecting your listening history…" else "Your monthly listening history will show up here.")
                        } else {
                            recap.songs.forEachIndexed { index, song ->
                                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                    Text("${index + 1}. ${song.title}", style = MaterialTheme.typography.titleMedium)
                                    Text(listOfNotNull(song.artistName, song.songCountListened.takeIf { it > 0 }?.let { "$it plays" }).joinToString(" • "), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
            }
            item {
                Text(
                    "Recap dibuat dari riwayat pemutaran yang tersimpan di perangkat ini.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun RecapMetricCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, style = MaterialTheme.typography.labelLarge)
            Text(value, style = MaterialTheme.typography.headlineSmall)
        }
    }
}

@Composable
private fun RecapSectionCard(title: String, primary: String, secondary: String) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh)) {
        Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
            Text(primary, style = MaterialTheme.typography.headlineSmall)
            Text(secondary, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
