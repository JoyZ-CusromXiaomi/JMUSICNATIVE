# JoyMusic — Android Music Player

JoyMusic adalah build bermerek JoyMusic dari source project Metrolist, aplikasi pemutar musik Android open-source berbasis Kotlin, Jetpack Compose, Media3, dan YouTube Music InnerTube.

## Fitur utama dari source yang disertakan

- Streaming lagu dan video dari YouTube Music.
- Playback latar belakang dan kontrol media Android.
- Pencarian lagu, video, album, artis, dan playlist.
- Quick picks, riwayat, rekomendasi, dan playlist.
- Mini-player dan full player.
- Download/cache untuk pemutaran offline.
- Lirik tersinkronisasi dan pilihan penyedia lirik.
- Sleep timer, skip silence, normalisasi audio, tempo/pitch, equalizer, dan crossfade.
- Mode tema gelap/hitam, warna dinamis, dan pengaturan tampilan.
- Library lokal dan sinkronisasi akun YouTube Music sesuai dukungan upstream.

Ketersediaan stream tetap bergantung pada layanan YouTube/YouTube Music, jaringan, dan perubahan protokol pihak ketiga. Tidak ada jaminan seluruh konten selalu tersedia.

## Identitas JoyMusic

- Nama aplikasi: `JoyMusic`
- Application ID: `com.joymusic.app`
- Project type: **Native Android (Kotlin + Gradle)** — bukan Flutter.
- Build variant: `fossRelease`
- Release APK ditandatangani dengan debug keystore pada workflow untuk instalasi uji/sideload.

## Cara membuat APK tanpa terminal

Proyek ini menyertakan workflow GitHub Actions:

1. Buat repository GitHub baru.
2. Unggah seluruh isi ZIP ini ke root repository (bukan folder pembungkus).
3. Buka tab **Actions**.
4. Pilih **Build JoyMusic APK**.
5. Tekan **Run workflow**.
6. Setelah selesai, unduh artifact **JoyMusic-APK** dari halaman run tersebut.

**Penting:** ZIP ini adalah proyek Android native. Bot Telegram yang hanya menerima proyek Flutter (`pubspec.yaml`) tidak dapat membangunnya. Gunakan GitHub Actions yang sudah disertakan atau builder yang mendukung Android Gradle/Kotlin.

## Lisensi dan atribusi

JoyMusic pada paket ini merupakan modifikasi/rebranding dari proyek Metrolist. Source upstream dilisensikan di bawah GNU General Public License v3.0. Lisensi, atribusi, dan pemberitahuan hak cipta upstream dipertahankan. Lihat file `LICENSE` dan riwayat proyek upstream untuk informasi kontributor.

Source upstream: https://github.com/MetrolistGroup/Metrolist

## Compatibility adjustment
For GitHub-hosted builds, Android `compileSdk` is set to API 36 because the SDK manager used by the workflow does not currently provide `platforms;android-37`. The app target SDK remains 36. This avoids requesting an unavailable SDK package during CI setup.

## Coil / Android API compatibility fix
The build log showed Coil 3.6.3 Android artifacts require compileSdk 37, while the GitHub runner SDK available to this workflow is API 36. Coil is pinned to 3.5.0, whose Android artifacts were built with compileSdk 36, while the app remains on compileSdk 36. No Coil API usage was changed; this is a dependency version alignment.

## Android 17 / API 37 build alignment
The source is aligned to compileSdk 37 because the current AndroidX/Compose dependencies require API 37. The CI workflow installs the SDK package `platforms;android-37.0` and creates the `platforms/android-37` alias expected by Android Gradle Plugin. targetSdk remains 36 to avoid opting into Android 17 runtime behavior changes unintentionally.
